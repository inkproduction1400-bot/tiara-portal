// lib/mdx.ts
import { compileMDX } from 'next-mdx-remote/rsc';
import remarkGfm from 'remark-gfm';
import rehypeSlug from 'rehype-slug';
import rehypeAutolinkHeadings from 'rehype-autolink-headings';
import fs from 'node:fs/promises';
import path from 'node:path';

export async function loadDoc(slugParts: string[]) {
  const rel = path.join('content', 'docs', ...slugParts) + (slugParts.at(-1)?.endsWith('.md') ? '' : '.md');
  const abs = path.join(process.cwd(), rel);
  const source = await fs.readFile(abs, 'utf8');
  const { content } = await compileMDX({
    source,
    options: {
      parseFrontmatter: true,
      mdxOptions: {
        remarkPlugins: [remarkGfm],
        rehypePlugins: [rehypeSlug, [rehypeAutolinkHeadings, { behavior: 'wrap' }]],
      },
    },
  });
  return content;
}
